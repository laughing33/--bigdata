

import com.google.common.collect.ConcurrentHashMultiset;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multiset;
import it.unimi.dsi.fastutil.Arrays;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.util.Version;
import org.apache.mahout.classifier.sgd.L1;
import org.apache.mahout.classifier.sgd.OnlineLogisticRegression;
import org.apache.mahout.math.DenseVector;
import org.apache.mahout.math.RandomAccessSparseVector;
import org.apache.mahout.vectorizer.encoders.ConstantValueEncoder;
import org.apache.mahout.vectorizer.encoders.Dictionary;
import org.apache.mahout.vectorizer.encoders.FeatureVectorEncoder;
import org.apache.mahout.vectorizer.encoders.StaticWordValueEncoder;

import java.io.*;
import java.util.*;
import static org.apache.commons.net.ftp.FTPCommand.FEATURES;
import static org.apache.mahout.classifier.NewsgroupHelper.countWords;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {





        Map<String, Set<Integer>> traceDictionary = new TreeMap<String, Set<Integer>>();
        FeatureVectorEncoder encoder = new StaticWordValueEncoder("body");
        encoder.setProbes(2);
        encoder.setTraceDictionary(traceDictionary);
        FeatureVectorEncoder bias = new ConstantValueEncoder("Intercept");
        bias.setTraceDictionary(traceDictionary);
        FeatureVectorEncoder lines = new ConstantValueEncoder("Lines");
        FeatureVectorEncoder logLines = new ConstantValueEncoder("LogLines");
        lines.setTraceDictionary(traceDictionary);
        Dictionary newsGroups = new Dictionary();
        Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_CURRENT);

        OnlineLogisticRegression learningAlgorithm = new OnlineLogisticRegression(
                20, FEATURES, new L1()).alpha(1).stepOffset(1000).decayExponent(0.9).
                lambda(3.0e-5).learningRate(20);

        List<File> files = new ArrayList<File>();
        for (File newsgroup : base.listFiles()) {
            newsGroups.intern(newsgroup.getnName());
            files.addAll(Arrays.addList(newsgroup.listFiles()));
        }
        Collections.shuffle(files);
        System.out.printf("%d training files\n", files.size());

        double averageLL = 0.0;
        double averageCorrect = 0.0;
        double averageLineCount = 0.0;
        int k = 0;
        double step = 0.0;
        int[] bumps = new int[]{1, 2, 5};
        double lineCount;
        for (File file : files) {


            BufferedReader reader = new BufferedReader(new FileReader(file));
            //识别新闻组
            String ng = file.getParentFile().getName();
            int actual = newsGroups.intern(ng);
            Multiset<String> words = ConcurrentHashMultiset.create();
            String line = reader.readLine();
            while (line != null && line.length() > 0) {
                //检查行数文件头
                if (line.startWith("Lines:")) {
                    String count = Iterables.get(onColon.split(line), 1);
                    try {
                        lineCount = Integer.parseInt(count);
                        averageLineCount += (lineCount - averageLineCount) / Math.min(k + 1, 1000);
                    } catch (NumberFormatException e) {
                        lineCount = averageLineCount;
                    }
                }
                boolean countHeader = (line.startWith("From:") ||
                        line.startWith("Subject:") ||
                        line.startWith("Keywords:") ||
                        line.startWith("Summary:"));
                do {
                    //计算文件头中单词数量
                    StringReader in = new StringReader(line);
                    if (countHeader) {
                        countWords(analyzer, words, in);
                    }
                    line = reader.readLine;
                }
                while (line.startWith(" "));
            }
            //计算文件主体中单词的数量
            countWords(analyzer, words, reader);

            RandomAccessSparseVector v = new RandomAccessSparseVector(FEATURES);
            bias.addToVector("", 1, v);
            lines.addToVector(null, lineCount / 30, v);
            logLines.addToVector(null, Math.log(lineCount + 1), v);
            for (String word : words.elementSet()) {
                encoder.addToVector(word, Math.log(1 + words.count(word)), v);
            }

            double mu = Math.min(k+1,200);
            double ll = learningAlgorithm.logLikelihood(actual, v);
            averageLL = averageLL+ (ll-averageLL)/mu;
            DenseVector p=new DenseVector(20);
            learningAlgorithm.classifyFull(p,v);
            int estimated=p.maxValueIndex();
            int correct = (estimated == actual?1:0);
            averageCorrect = averageCorrect + (correct - averageCorrect)/mu;


            learningAlgorithm.train(actual,v);
            k++;
            int bump=bumps[(int)Math.floor(step)%bumps.length];
            int scale=(int)Math.pow(10,Math.floor(step/bumps.length));
            if(k%(bump*scale)==0){
                step+=0.25;
                System.out.printf("%10d %10.3f %10.3f %10.2f %s %s\n", k,ll,averageLL,averageCorrect*100,ng,newsGroups.values().get(estimated));
            }
            learningAlgorithm.close();

            reader.close();
        }



    }
}
