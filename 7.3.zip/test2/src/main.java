



import com.sun.jersey.spi.StringReader;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.core.LowerCaseFilter;
import org.apache.lucene.analysis.core.StopFilter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.util.Version;
import org.apache.mahout.clustering.Cluster;
import org.apache.mahout.clustering.canopy.CanopyDriver;
import org.apache.mahout.clustering.classify.WeightedVectorWritable;
import org.apache.mahout.clustering.kmeans.KMeansDriver;
import org.apache.mahout.common.HadoopUtil;
import org.apache.mahout.common.distance.EuclideanDistanceMeasure;
import org.apache.mahout.common.distance.TanimotoDistanceMeasure;
import org.apache.mahout.vectorizer.DictionaryVectorizer;
import org.apache.mahout.vectorizer.DocumentProcessor;
import org.apache.mahout.vectorizer.tfidf.TFIDFConverter;
import org.apache.xerces.impl.xs.identity.Selector;


import java.io.IOException;
import java.io.Reader;
import java.util.regex.Pattern;

public class main {
    public static void main(String[] args) throws IOException {
        int minSupport = 2;
        int minDf=5;
        int maxDFPercent=95;
        int maxNGramSize=2;
        int minLLRValue=50;
        int reduceTasks=1;
        int chunkSize=200;
        int norm=2;
        boolean sequentialAccessOutput=true;
        String inputDir="inputDir";
        Configuration conf=new Configuration();
        FileSystem fs=FileSystem.get(conf);
        String outputDir="newsClusters";
        HadoopUtil.delete(new Path(outputDir));
        Path tokenizedPath = new Path(outputDir, DocumentProcessor.TOKENIZED_DOCUMENT_OUTPUT_FOLDER);
        //自定义lucene Analyzer
        MyAnalyzer analyzer=new MyAnalyzer();
        //文本词条化
        DocumentProcessor.tokenizeDocuments(new Path(inputDir), analyzer.getClass().asSubclass(Analyzer.class), tokenizedPath, conf);
        DictionaryVectorizer.createTermFrequencyVectors (tokenizedPath, new Path(outputDir), conf, minSupport, maxNGramSize, minLLRValue, 2, true, reduceTasks, chunkSize, sequentialAccessOutput, false);
        //计算TF-IDF向量
        TFIDFConverter.processTfIdf (new Path(outputDir, DictionaryVectorizer.DOCUMENT_VECTOR_OUTPUT_FOLDER), new Path(outputDir), conf, chunkSize, minDf, maxDFPercent, norm, true, sequentialAccessOutput, false, reduceTasks);
        Path vectorsFolder=new Path (outputDir, "tfidf-vectors");
        Path canopyCentroids=new Path (outputDir, "canopy-centroids");
        Path clusterOutput=new Path(outputDir,"clusters");
        //执行Canopy算法生成初始聚类中心
        CanopyDriver.run(vectorsFolder,canopyCentroids,new EuclideanDistanceMeasure(),250,120,false,false,true);
        //运行K-means算法
        KMeansDriver.run(conf, vectorsFolder, new Path(canopyCentroids,"clusters-0"), clusterOutput, new TanimotoDistanceMeasure(), 0.01, 20, true, false);
        SequenceFile.Reader reader=new SequenceFile.Reader(fs, new Path (clusterOutput + Cluster.INITIAL_CLUSTERS_DIR +"/part-00000"), conf);
        IntWritable key =new IntWritable();
        WeightedVectorWritable value =new WeightedVectorWritable();
        //读取vector做聚类映射
        while (reader.next(key,value)){
            System.out.println(key.toString()+"belongs to cluster"+ value.toString());
        }
        reader.close();

    }
}

public class MyAnalyzer extends Analyzer {
    private final Pattern alphabets = Pattern.compile("[a-z]+");
    @Override
    public TokenStream tokenStream (String fieldName, Reader reader) {
        //使用Lucene过滤器
        TokenStream result=new StandardTokenizer(Version.LUCENE_CURRENT, reader);
        result=new StandardFilter(result);
        result=new LowerCaseFilter(result);
        result=new StopFilter(true, result, StandardAnalyzer.STOP_WORDS_SET);
        TermAttribute termAtt=(TermAttribute) result.addAttribute(TermAttribute.class);
        StringBuilder buf=new StringBuilder ();
        try {
            while (result.incrementToken()){
                //过滤短词条
                if (termAtt.termLength () < 3) continue;
                String word=new String (termAtt.termBuffer(), 0, termAtt.termLength());
                Selector.Matcher m = alphabets.matcher (word);
                //过滤非字母词条
                if(m.matches()){
                    buf.append(word).append(" ");
                }
            }
        } catch(IOException e){
                e.printStackTrace();
        }
        return new WhiteSpaceTokenizer (new StringReader(buf.toString()));
    }
}
